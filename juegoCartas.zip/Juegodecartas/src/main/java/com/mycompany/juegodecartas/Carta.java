package com.mycompany.juegodecartas;


public class Carta {
    private final int idCarta;
    private static int contadorCartas;
    private final String nombrePersonaje;
    private final int fuerza;
    private final int agilidad;
    private final int inteligencia;
    private final int vida;
    
    private Carta(){
        this.idCarta = ++Carta.contadorCartas;
    }
    
    public Carta(String nombrePer, int Fuerza, int Agilidad, int Inteligencia, int Vida){
        this();
        this.nombrePersonaje = nombrePer;
        this.fuerza = Fuerza;
        this.agilidad = Agilidad;
        this.inteligencia = Inteligencia;
        this.vida = Vida;
    }

    public int getIdCarta() {
        return idCarta;
    }

    public String getNombrePersonaje() {
        return nombrePersonaje;
    }

    public int getFuerza() {
        return fuerza;
    }

    public int getAgilidad() {
        return agilidad;
    }

    public int getInteligencia() {
        return inteligencia;
    }

    public int getVida() {
        return vida;
    }

    @Override
    public String toString() {
        return "Carta{" + "idCarta=" + idCarta + ", Personaje = " + nombrePersonaje + ", Fuerza = " + fuerza + ", Agilidad = " + agilidad + ", Inteligencia = " + inteligencia + ", Vida = " + vida + '}';
    }
    
    
}
