package com.mycompany.juegodecartas;


public class Jugador {
    private String nombreJugador;
    private static int contadorJugadores;
    private int numeroJugador;
    private Carta cartaEnMano;
    private mazoPersonal mazoPersonal;
    
    
    
    private Jugador() {
        this.numeroJugador = ++contadorJugadores;
    }

    public Jugador(String nombre) {
        this();
        this.nombreJugador = nombre;
    }

    public Carta getCartaEnMano() {
        return cartaEnMano;
    }

    public void setCartaEnMano(Carta cartaEnMano) {
        this.cartaEnMano = cartaEnMano;
    }

    public mazoPersonal getMazoPersonal() {
        return mazoPersonal;
    }

    public void setMazoPersonal(mazoPersonal mazoPersonal) {
        this.mazoPersonal = mazoPersonal;
    }

    
}
